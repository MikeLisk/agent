# 介绍

本项目是一个示例用的天气 Agent，用于在 A2A 演示中作为 Remote Agent 使用。

# 启动方法

在当前目录下执行如下命令即可启动：

```sh
uv run .
```