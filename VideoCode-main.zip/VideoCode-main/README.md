本仓库用于存储“马克的技术工作坊”的示例代码。全网同名，如果你所看视频的博主名不叫“马克的技术工作坊”，那么你观看的一定是别人搬运的盗版视频，请告知我或直接帮我举报，谢谢！

目前我仅在如下这四个平台有发布视频，具体地址如下：

- YouTube: https://www.youtube.com/@马克的技术工作坊
- BiliBili: https://space.bilibili.com/1815948385
- 小红书: https://www.xiaohongshu.com/user/profile/64687d3a000000002901216f
- 抖音: https://www.douyin.com/user/MS4wLjABAAAAwmE-l6oONkP3R29nUSrJlE6gov-8Qq7VinKzNcUvRU0
